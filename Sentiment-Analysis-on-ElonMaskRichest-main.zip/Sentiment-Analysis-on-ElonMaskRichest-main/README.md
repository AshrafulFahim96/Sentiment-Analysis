# Sentiment-Analysis on #ElonMaskRichest

Data Acquistion - Scrapped #elonmask #richest from twittwer tweets and comments

Data Preparation - Used Natural Language Processing for data cleaning and processing 

Sentiment Analysis Tool - TextBlob & Vader

Data Visualization Tool - WordCloud


Step 01 -  Call the libraries
Step 02 - Imoort the data using pandas
Step 03 - Clean the unwanted words
Step 04 - Visaulize the most occured words
Step 05 - Call the analysis tool 
Step 06 - Visualize and save the results
